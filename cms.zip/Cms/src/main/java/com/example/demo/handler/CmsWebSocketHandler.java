package com.example.demo.handler;

import java.io.IOException;

import org.springframework.stereotype.Component;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

@Component
public class CmsWebSocketHandler extends TextWebSocketHandler {
    private WebSocketSession cpSession;

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        System.out.println("✅ CP connected: " + session.getId());
        session.sendMessage(new TextMessage("{\"message\": \"Welcome CP\"}"));
    }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        System.out.println("📥 Message from CP: " + message.getPayload());

        // Optional: send response
        if (message.getPayload().contains("status")) {
            session.sendMessage(new TextMessage("{\"command\": \"reboot\"}"));
        }
    }

	public WebSocketSession getCpSession() {
		return cpSession;
	}

	public void setCpSession(WebSocketSession cpSession) {
		this.cpSession = cpSession;
	}

	public void sendMessageToCP(String msg) {
		// TODO Auto-generated method stub
		
	}
}

