package com.example.demo.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.handler.CmsWebSocketHandler;

@RestController
public class WebSocketController {
    @Autowired
    private CmsWebSocketHandler cmsWebSocketHandler;

    @GetMapping("/sendToCP")
    public String sendToCP(@RequestParam String msg) throws IOException {
        cmsWebSocketHandler.sendMessageToCP(msg);
        return "Message sent to CP!";
    }
}

